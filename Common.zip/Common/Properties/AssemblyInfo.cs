using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("XHD.Common")]
[assembly: AssemblyDescription("Common Library By XHD")]
[assembly: AssemblyConfiguration("crm_123Admin")]
[assembly: AssemblyCompany("����׿Խ���������Ƽ����޹�˾")]
[assembly: AssemblyProduct("XHD.Common")]
[assembly: AssemblyCopyright("Copyright (C) XHD 2004-2012")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]	
[assembly: AssemblyVersion("3.5.0")]	
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
